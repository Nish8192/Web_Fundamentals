# Dojo Arena
#### Clone this repo to your Desktop

##### In this group activity, you and your partner will be creating the opening sequences of a Street Fighter-like game. The wireframes and images are provided in this repo. It is not required to use the same images. Have fun!



##### Assignment Instructions:

1. When the document loads, display a game window with a "Select Arena" module with 6 different arena options. When the user hovers over each button, the correct image of the arena should be displayed onto the game window. __*Refer to Wireframe 1*__

2. When the user selects an arena, the arena image will fix to the game window and a new module will appear that allows the user(s) to select their game players. __*Refer to Wireframe 2*__

3. As the user(s) select their game players, the player images will fix to the screen. __*Refer to Wireframe 3*__
